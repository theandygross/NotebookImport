from distutils.core import setup

setup(name='NotebookImport',
      version='0.1',
      py_modules=['NotebookImport'],
      )
